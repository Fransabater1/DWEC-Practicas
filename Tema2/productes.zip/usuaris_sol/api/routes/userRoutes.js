// import express from 'express';

// import { getUsuarios, login, registrar } from '../controllers/userController.js';
// import { verifyToken, requireAdmin } from '../middlewares/authMiddleware.js';

// const router = express.Router();
// const endpoint = '/api/users';

// router.get(endpoint, verifyToken, requireAdmin, getUsuarios);

// router.post(endpoint, verifyToken, registrar); 

// router.post('/login', login);



// export default router;